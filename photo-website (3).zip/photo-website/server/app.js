const express = require('express');
const path = require('path');
const cors = require('cors');
const mysql = require('mysql2');
const multer = require('multer'); // ✅ ADDED: For handling room image uploads
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

// ✅ Middleware
app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: false }));

// ✅ Static folders
app.use(express.static(path.join(__dirname, '../public')));
app.use('/uploads', express.static(path.join(__dirname, '../uploads'))); // ✅ ADDED: Serve uploaded room images

// ✅ MySQL Connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'websiteDB'
});

db.connect(err => {
  if (err) {
    console.error('❌ MySQL connection error:', err);
    return;
  }
  console.log('✅ Connected to MySQL');
});

// ✅ Test route
app.get('/test', (req, res) => {
  res.send('✅ Server is alive');
});

// ✅ Login route
app.post('/login', (req, res) => {
  const { email, password } = req.body;
  console.log('📅 Login attempt:', email);

  const sql = 'SELECT * FROM users WHERE email = ? AND password = ?';
  db.query(sql, [email, password], (err, results) => {
    if (err) {
      console.error('❌ Login query error:', err);
      return res.status(500).json({ success: false, message: 'Server error' });
    }
    if (results.length > 0) {
      console.log('✅ Login successful');
      return res.json({ success: true });
    } else {
      console.log('❌ Invalid credentials');
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }
  });
});

// ✅ Image Upload route
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, '../uploads'));
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage });

app.post('/upload', upload.single('image'), (req, res) => {
  res.json({ filename: req.file.filename, path: `/uploads/${req.file.filename}` });
});

// ✅ Check Availability Route
app.post('/check-availability', (req, res) => {
  const { arrivalDate, departureDate } = req.body;

  const query = `
    SELECT * FROM available_rooms 
    WHERE is_available = TRUE
  `;

  db.query(query, (err, results) => {
    if (err) {
      console.error('❌ Availability query error:', err);
      return res.status(500).json({ available: false, error: 'Server error' });
    }

    if (results.length > 0) {
      return res.json({ available: true, rooms: results });
    } else {
      return res.json({ available: false });
    }
  });
});

// ✅ Book Now Route (must exist for booking)
app.post('/book-now', (req, res) => {
  const { name, email, phone, arrivalDate, departureDate, guests, roomId } = req.body;

  const insertBooking = `
    INSERT INTO bookings (name, email, phone, arrival_date, departure_date, guests, room_id, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'confirmed')
  `;

  db.query(insertBooking, [name, email, phone, arrivalDate, departureDate, guests, roomId], (err, result) => {
    if (err) {
      console.error('❌ Booking insertion error:', err);
      return res.status(500).json({ success: false, message: 'Failed to book room' });
    }

    // ✅ Mark the room as unavailable
    const updateRoom = 'UPDATE available_rooms SET is_available = FALSE WHERE id = ?';
    db.query(updateRoom, [roomId], (err2) => {
      if (err2) {
        console.error('❌ Room update error:', err2);
        return res.status(500).json({ success: false, message: 'Room update failed' });
      }

      res.json({ success: true, message: 'Room booked successfully' });
    });
  });
});

// ✅ Default route
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// ✅ Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});

// ✅ Get all rooms
app.get('/rooms', (req, res) => {
  db.query('SELECT * FROM rooms', (err, results) => {
    if (err) return res.status(500).json({ success: false });
    res.json(results);
  });
});

// ✅ ADDED: Create a new room with image (uploaded)
app.post('/rooms', upload.single('image'), (req, res) => {
  const { name, price, description } = req.body;
  const image = req.file ? req.file.filename : null; // ✅ ADDED: Get uploaded image filename
  db.query('INSERT INTO rooms (name, price, description, image) VALUES (?, ?, ?, ?)',
    [name, price, description, image], err => {
      if (err) return res.status(500).json({ success: false });
      res.json({ success: true });
    });
});

// ✅ Update a room (without changing image)
app.put('/rooms/:id', upload.single('image'), (req, res) => {
  const { id } = req.params;
  const { name, price, description } = req.body;
  const image = req.file ? req.file.filename : null;

  let sql = 'UPDATE rooms SET name = ?, price = ?, description = ?';
  const params = [name, price, description];

  if (image) {
    sql += ', image = ?';
    params.push(image);
  }

  sql += ' WHERE id = ?';
  params.push(id);

  db.query(sql, params, err => {
    if (err) return res.status(500).json({ success: false });
    res.json({ success: true });
  });
});


// ✅ Delete a room
app.delete('/rooms/:id', (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM rooms WHERE id = ?', [id], err => {
    if (err) return res.status(500).json({ success: false });
    res.json({ success: true });
  });
});

// ✅ Optional: Another endpoint to fetch rooms
app.get('/api/rooms', (req, res) => {
  db.query('SELECT * FROM rooms', (err, results) => {
    if (err) {
      console.error('❌ Error fetching rooms:', err);
      return res.status(500).json({ success: false, message: 'Database error' });
    }
    res.json(results);
  });
});
