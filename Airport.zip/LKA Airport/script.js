document.addEventListener('DOMContentLoaded', function () {
    var swiper = new Swiper('.swiper-container', {
        slidesPerView: 1,
        spaceBetween: 30,
        loop: true,
        autoplay: {
            delay: 3000,
            disableOnInteraction: false,
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
    });
});
$(document).ready(function () {
    // Initialize bxSlider for the slider
    $(".swiper-container").swiper({
        slidesPerView: 1,
        spaceBetween: 30,
        loop: true,
        autoplay: {
            delay: 3000,
            disableOnInteraction: false,
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
    });

    // Hover effect for slider buttons
    $('#slider .btn-more').hover(
        function () {
            $(this).css({
                'color': '#fff',
                'border': '1px solid #fff'
            });
        },
        function () {
            $(this).css({
                'color': '#a5b1d5',
                'border': '1px solid #a5b1d5'
            });
        }
    );
});
