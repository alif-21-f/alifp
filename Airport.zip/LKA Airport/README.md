A static website for an international airport built from a blank page with HTML and CSS
