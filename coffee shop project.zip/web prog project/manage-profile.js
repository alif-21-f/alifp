// Logout function
function logout() {
    // Redirect to home.html
    window.location.href = 'home.html';
}
