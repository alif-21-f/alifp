const itemList = document.getElementById("itemList");
const notification = document.getElementById("notification");

function addItem() {
    const itemName = document.getElementById("itemName").value;
    const itemPrice = document.getElementById("itemPrice").value;
    const itemPhoto = document.getElementById("itemPhoto").files[0];

    if (!itemName || !itemPrice || !itemPhoto) {
        showNotification("Please enter the item name, price, and select a photo.", "error");
        return;
    }

    const reader = new FileReader();
    reader.onload = function(e) {
        const item = document.createElement("li");
        item.className = "item";
        item.innerHTML = `
            <input type="checkbox" class="item-checkbox">
            <img src="${e.target.result}" alt="${itemName}">
            <span>${itemName} - $<span class="price">${itemPrice}</span></span>
            <div class="actions">
                <button class="edit-button" onclick="editItem(this)">Edit</button>
                <button class="delete-button" onclick="deleteItem(this)">Delete</button>
            </div>
        `;

        itemList.appendChild(item);

        document.getElementById("itemName").value = "";
        document.getElementById("itemPrice").value = "";
        document.getElementById("itemPhoto").value = "";

        showNotification("Item added successfully.", "success");
    };

    reader.readAsDataURL(itemPhoto);
}

function deleteItem(button) {
    const item = button.parentElement.parentElement;
    itemList.removeChild(item);
    showNotification("Item deleted successfully.", "success");
}

function editItem(button) {
    const item = button.parentElement.parentElement;
    const currentPrice = item.querySelector(".price").textContent;

    const action = prompt("Enter '1' to delete or '2' to change price:", "1 or 2");

    if (action === "1") {
        itemList.removeChild(item);
        showNotification("Item deleted successfully.", "success");
    } else if (action === "2") {
        const newPrice = prompt("Enter the new price:", currentPrice);

        if (newPrice) {
            item.querySelector(".price").textContent = newPrice;
            showNotification("Price updated successfully.", "success");
        }
    } else {
        showNotification("Invalid input. Please enter '1' or '2'.", "error");
    }
}

function confirmDeleteSelectedItems() {
    const confirmation = confirm("Are you sure you want to delete the selected items?");
    if (confirmation) {
        deleteSelectedItems();
    }
}

function deleteSelectedItems() {
    const checkboxes = document.querySelectorAll(".item-checkbox");
    let deleted = false;
    checkboxes.forEach((checkbox) => {
        if (checkbox.checked) {
            const item = checkbox.parentElement;
            itemList.removeChild(item);
            deleted = true;
        }
    });
    if (deleted) {
        showNotification("Selected items deleted successfully.", "success");
    } else {
        showNotification("No items selected for deletion.", "error");
    }
}

function showNotification(message, type) {
    notification.textContent = message;
    notification.className = `notification ${type}`;
    notification.style.display = "block";

    setTimeout(() => {
        notification.style.display = "none";
    }, 3000);
}
