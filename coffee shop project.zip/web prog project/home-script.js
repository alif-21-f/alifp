
 let cartCount = 0;

  function openMenuModal(coffeeName) {
    document.getElementById('menu-modal').style.display = 'block';
    document.getElementById('selected-coffee-title').innerText = coffeeName;
  }

  function closeMenuModal() {
    document.getElementById('menu-modal').style.display = 'none';
  }

  function addToCart() {
    const size = document.getElementById('size').value;
    const temperature = document.getElementById('temperature').value;
    alert(`Added to cart: Size - ${size}, Temperature - ${temperature}°C`);
    cartCount++;
    document.getElementById('cart-count').innerText = cartCount;
    closeMenuModal();
  }

  // Update temperature output as the slider is moved
  document.getElementById('temperature').addEventListener('input', function() {
    document.getElementById('temp-output').innerText = this.value + '°C';
  });
  document.getElementById('filter-btn').addEventListener('click', function() {
    const filterOptions = document.getElementById('filter-options');
    if (filterOptions.style.display === 'none' || filterOptions.style.display === '') {
        filterOptions.style.display = 'block'; // Show the filter options
    } else {
        filterOptions.style.display = 'none'; // Hide the filter options
    }
});
// JavaScript code for filtering and searching coffee items
document.getElementById("search-form").addEventListener("submit", function (event) {
  event.preventDefault();

  // Get search query and filter values
  const searchQuery = document.getElementById("search-coffee").value.toLowerCase();
  const coffeeType = document.getElementById("coffee-type").value;
  const minPrice = parseFloat(document.getElementById("min-price").value);
  const maxPrice = parseFloat(document.getElementById("max-price").value);

  // Sample array of coffee products
  const coffeeItems = [
      { name: "Espresso", type: "espresso", price: 2.5 },
      { name: "Latte", type: "latte", price: 3.0 },
      { name: "Cappuccino", type: "cappuccino", price: 3.5 },
      { name: "Americano", type: "americano", price: 2.0 },
      { name: "Mocha", type: "mocha", price: 4.0 }
  ];

  // Filter coffee items based on criteria
  const filteredItems = coffeeItems.filter((item) => {
      const matchesSearch = item.name.toLowerCase().includes(searchQuery);
      const matchesType = coffeeType === "" || item.type === coffeeType;
      const matchesMinPrice = isNaN(minPrice) || item.price >= minPrice;
      const matchesMaxPrice = isNaN(maxPrice) || item.price <= maxPrice;
      return matchesSearch && matchesType && matchesMinPrice && matchesMaxPrice;
  });

  // Display filtered results (you may want to render this dynamically in your HTML)
  console.log("Filtered Items:", filteredItems);
  alert("Filtered Results: " + JSON.stringify(filteredItems));
});
// Toggle visibility of filter options
document.getElementById("filter-btn").addEventListener("click", function () {
  document.getElementById("filter-options").classList.toggle("show");
});
document.getElementById("search-form").addEventListener("submit", function (event) {
  event.preventDefault();

  // Get search query and filter values
  const searchQuery = document.getElementById("search-coffee").value.toLowerCase();
  const coffeeType = document.getElementById("coffee-type").value;
  const minPrice = parseFloat(document.getElementById("min-price").value);
  const maxPrice = parseFloat(document.getElementById("max-price").value);

  // Sample array of coffee products with ids
  const coffeeItems = [
      { id: "coffee-espresso", name: "Espresso", type: "espresso", price: 3.0 },
      { id: "coffee-latte", name: "Latte", type: "latte", price: 3.0 },
      { id: "coffee-cappuccino", name: "Cappuccino", type: "cappuccino", price: 3.5 },
      { id: "coffee-americano", name: "Americano", type: "americano", price: 2.0 },
      { id: "coffee-mocha", name: "Mocha", type: "mocha", price: 4.0 }
  ];

  // Filter coffee items based on criteria
  const filteredItems = coffeeItems.filter((item) => {
      const matchesSearch = item.name.toLowerCase().includes(searchQuery);
      const matchesType = coffeeType === "" || item.type === coffeeType;
      const matchesMinPrice = isNaN(minPrice) || item.price >= minPrice;
      const matchesMaxPrice = isNaN(maxPrice) || item.price <= maxPrice;
      return matchesSearch && matchesType && matchesMinPrice && matchesMaxPrice;
  });

  // Check if there are matching items and scroll to the first one
  if (filteredItems.length > 0) {
      const firstMatchId = filteredItems[0].id;
      const firstMatchElement = document.getElementById(firstMatchId);

      if (firstMatchElement) {
          // Scroll to the matched element
          firstMatchElement.scrollIntoView({ behavior: "smooth", block: "center" });

          // Highlight the matched element
          firstMatchElement.classList.add("highlight");
          setTimeout(() => {
              firstMatchElement.classList.remove("highlight");
          }, 2000); // Remove highlight after 2 seconds
      }
  } else {
      alert("No matching items found.");
  }
  // Select the seller button element
const sellerButton = document.getElementById("sellerButton");

// Function to show the button when the user scrolls near the bottom
function toggleSellerButton() {
    const scrollHeight = document.documentElement.scrollHeight;
    const currentScroll = window.scrollY + window.innerHeight;

    // Show button when the user scrolls to the last 300px of the page
    if (scrollHeight - currentScroll <= 300) {
        sellerButton.classList.add("show");
    } else {
        sellerButton.classList.remove("show");
    }
}

// Listen for scroll events to trigger the function
window.addEventListener("scroll", toggleSellerButton);

});
