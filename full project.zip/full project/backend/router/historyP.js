const express = require('express');
const router = express.Router();
const db = require("../db");
const path = require('path');


router.get('/purchases', (req, res) => {
    const userId = req.session.userId; 

    if (!userId) {
        return res.redirect('/login'); 
    }

   
    res.sendFile(path.join(__dirname, '../../public', 'history.html'));
});


router.post('/api/confirm-purchase', (req, res) => {
    const userId = req.session.userId; 

    if (!userId) {
        return res.status(401).json({ message: 'User not authenticated' });
    }

    
    const cartItemsQuery = `
        SELECT sc.product_id, sc.quantity, sc.size, p.seller_id, p.price  -- Include price
        FROM shopping_cart sc
        JOIN products p ON sc.product_id = p.id
        WHERE sc.user_id = ?`;

    db.query(cartItemsQuery, [userId], (error, cartItems) => {
        if (error) {
            console.error('Error fetching cart items:', error);
            return res.status(500).json({ message: 'Error fetching cart items' });
        }

        if (cartItems.length === 0) {
            return res.status(400).json({ message: 'Shopping cart is empty' });
        }

        
        let purchaseQueries = cartItems.map(item => {
            const totalPrice = item.price * item.quantity;  

            return new Promise((resolve, reject) => {
                db.query(`
                    INSERT INTO purchase_history (user_id, product_id, quantity, size, seller_id, price)  -- Add price here
                    VALUES (?, ?, ?, ?, ?, ?)`,
                    [userId, item.product_id, item.quantity, item.size, item.seller_id, totalPrice],  
                    (error, results) => {
                        if (error) {
                            return reject(error);
                        }
                        resolve(results);
                    });
            });
        });

        Promise.all(purchaseQueries)
            .then(() => {
                
                db.query(`DELETE FROM shopping_cart WHERE user_id = ?`, [userId], (error) => {
                    if (error) {
                        console.error('Error clearing shopping cart:', error);
                        return res.status(500).json({ message: 'Error clearing shopping cart' });
                    }

                    res.status(200).json({ message: 'Purchase confirmed and saved to history' });
                });
            })
            .catch(error => {
                console.error('Error inserting into purchase history:', error);
                res.status(500).json({ message: 'An error occurred while saving to purchase history' });
            });
    });
});

router.get('/purchase-history', (req, res) => {
    const userId = req.session.userId; 

    if (!userId) {
        return res.status(401).json({ message: 'User not authenticated' });
    }

    
    db.query(`
        SELECT p.id, p.name, p.image, ph.quantity, ph.size, u.name AS sellerName, ph.price
        FROM purchase_history ph
        JOIN products p ON ph.product_id = p.id
        JOIN users u ON p.seller_id = u.id  -- Corrected this line to use 'u.id'
        WHERE ph.user_id = ?`, 
        [userId],
        (error, purchaseHistory) => {
            if (error) {
                console.error('Error fetching purchase history:', error);
                return res.status(500).json({ message: 'An error occurred while fetching purchase history' });
            }

            res.status(200).json(purchaseHistory);
        }
    );
});


module.exports = router;
