const express = require('express');
const router = express.Router();
const fs = require('fs'); // Required for handling file paths
const multer = require('multer'); // For handling file uploads
const db = require("../db");
const path = require('path');




const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, path.join(__dirname, '../../public/images'));
    },
    filename: function (req, file, cb) {
        // Use the original file name and add a timestamp to prevent name collisions
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });

router.get('/view-page', (req, res) => {
    const userId = req.session.userId;
    console.log('User ID:', userId);

    if (!userId) {
        return res.redirect('/login'); 
    }
    db.query('SELECT user_type FROM users WHERE id = ?', [userId], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).send('Internal Server Error');
        }

        
        if (results.length === 0) {
            return res.redirect('/login');
        }

        const userType = results[0].user_type;

        console.log('User Type:', userType);

        if (userType !== 'seller') {
            return res.redirect('/unauthorized'); 
        }



    res.sendFile(path.join(__dirname, '../../public', 'sellerpage.html'));
});
});




router.get('/api/products', (req, res) => {
    const userId = req.session.userId;

    if (!userId) {
        console.log('No user ID found in session');
        return res.status(401).json({ error: 'User not authenticated' });
    }

    console.log(`Fetching products for seller ID: ${userId}`);

    const query = 'SELECT * FROM products WHERE seller_id = ?';
    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching products:', err.message);
            return res.status(500).json({ error: err.message });
        }

        console.log('Query executed successfully. Results:', results);

        if (results.length === 0) {
            console.log('No products found for seller ID:', userId);
            return res.status(200).json([]);
        }

        res.json(results);
    });
});



router.post('/api/products', upload.single('image'), (req, res) => {
    const userId = req.session.userId;

    if (!userId) {
        return res.status(401).json({ message: 'User not authenticated' });
    }

    const { name, category, price, quantity, status } = req.body;

    // Validate required fields
    if (!name || !category || !price || !quantity || !req.file) {
        return res.status(400).json({ message: 'Missing required fields or image file' });
    }

    // Get the image file's relative path (Multer stores it in the "images" folder)
    const imagePath = '/images/' + req.file.filename;

    // Insert the new product into the database
    const query = 'INSERT INTO products (name, category, price, quantity, image, seller_id, status) VALUES (?, ?, ?, ?, ?, ?, ?)';
    db.query(query, [name, category, price, quantity, imagePath, userId, status || 'active'], (err, result) => {
        if (err) {
            console.error('Error adding product:', err);
            return res.status(500).json({ message: 'Error adding product to the database' });
        }

        // Return the newly created product with the generated ID and image path
        const newProduct = {
            id: result.insertId,  // MySQL will generate the ID
            name,
            category,
            price,
            quantity,
            image: '/images/' + req.file.filename,
            seller_id: userId,
            status: status || 'active',  // Default status is 'active' if not provided
        };

        // Send the newly created product back to the front-end
        res.json(newProduct);
    });
});



router.put('/api/products/:id', upload.single('image'), (req, res) => {
    const { name, category, price, quantity } = req.body;
    const productId = req.params.id;
    let newImage = null;

    // Check if a new image is uploaded
    if (req.file) {
        // Generate the relative path for the new image
        newImage = '/images/' + req.file.filename;
    }

    // Query to get the current image for the product
    const getCurrentProductQuery = 'SELECT image FROM products WHERE id = ?';
    db.query(getCurrentProductQuery, [productId], (err, result) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ message: 'Error retrieving product', error: err.message });
        }

        if (result.length === 0) {
            return res.status(404).json({ message: 'Product not found' });
        }

        const currentImage = result[0].image;

        // If no new image is provided, use the current image
        const imageToSave = newImage || currentImage;

        // Update product details in the database
        const updateQuery = 'UPDATE products SET name = ?, category = ?, price = ?, quantity = ?, image = ? WHERE id = ?';
        db.query(updateQuery, [name, category, price, quantity, imageToSave, productId], (err, result) => {
            if (err) {
                console.error('Database update error:', err);
                return res.status(500).json({ message: 'Error updating product', error: err.message });
            }

            res.json({ message: 'Product updated successfully' });
        });
    });
});




router.delete('/api/products/:id', (req, res) => {
    const userId = req.session.userId;
    const { id } = req.params;

    if (!userId) {
        return res.status(401).json({ error: 'User not authenticated' });
    }

    // Check if the product belongs to the logged-in user
    const checkQuery = 'SELECT * FROM products WHERE id = ? AND seller_id = ?';
    db.query(checkQuery, [id, userId], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (results.length === 0) {
            return res.status(403).json({ error: 'You are not authorized to delete this product' });
        }

        // Proceed with deleting the product
        const deleteQuery = 'DELETE FROM products WHERE id = ? AND seller_id = ?';
        db.query(deleteQuery, [id, userId], (err, result) => {
            if (err) {
                return res.status(500).json({ error: err.message });
            }
            res.json({ message: 'Product deleted successfully' });
        });
    });
});



router.put('/api/products-status/:id', (req, res) => {
    const productId = req.params.id;
    const { status } = req.body; // Get the new status from the request body

    if (!status || (status !== 'active' && status !== 'paused')) {
        return res.status(400).json({ message: 'Invalid status value' });
    }

    // Update the product's status in the database
    const updateQuery = 'UPDATE products SET status = ? WHERE id = ?';
    db.query(updateQuery, [status, productId], (err, result) => {
        if (err) {
            console.error('Database update error:', err);
            return res.status(500).json({ message: 'Error updating product status', error: err.message });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Product not found' });
        }

        res.json({ message: 'Product updated successfully' });
    });
});






// API to get user profile picture
router.get('/api/profile-picture', (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
        return res.status(401).json({ message: 'User not authenticated' });
    }

    const query = 'SELECT profile_picture FROM users WHERE id = ?';
    db.query(query, [userId], (error, results) => {
        if (error) {
            console.error('Error retrieving profile picture:', error);
            return res.status(500).json({ message: 'Error retrieving profile picture' });
        }

        if (results.length > 0) {
            res.json({ profilePicture: results[0].profile_picture });
        } else {
            res.status(404).json({ message: 'Profile picture not found' });
        }
    });
});



module.exports = router;