const express = require('express');
const router = express.Router();
const db = require("../db");
const path = require('path');


router.get('/view-orders', (req, res) => {
    const userId = req.session.userId;

    if (!userId) {
        return res.redirect('/login'); 
    }

    
    res.sendFile(path.join(__dirname, '../../public', 'soldHistory.html'));
});


router.get('/api/orders', (req, res) => {
    const userId = req.session.userId; 

    if (!userId) {
        return res.status(401).json({ message: 'User not authenticated' });
    }

    
    db.query( `
        SELECT 
    u.name AS customer_name,
    p.name AS product_name,      -- Add product name
    p.category AS product_category,
    p.image AS product_image,
    ph.price AS purchase_price,
    ph.quantity AS purchase_quantity
FROM 
    purchase_history ph
JOIN 
    users u ON ph.user_id = u.id
JOIN 
    products p ON ph.product_id = p.id
WHERE 
    p.seller_id = ?;

    `, 
        [userId],
        (error, purchaseHistory) => {
            if (error) {
                console.error('Error fetching purchase history:', error);
                return res.status(500).json({ message: 'An error occurred while fetching purchase history' });
            }

            res.status(200).json(purchaseHistory);  
        }
    );
});





// API to get user profile picture
router.get('/api/profile-picture', (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
        return res.status(401).json({ message: 'User not authenticated' });
    }

    const query = 'SELECT profile_picture FROM users WHERE id = ?';
    db.query(query, [userId], (error, results) => {
        if (error) {
            console.error('Error retrieving profile picture:', error);
            return res.status(500).json({ message: 'Error retrieving profile picture' });
        }

        if (results.length > 0) {
            res.json({ profilePicture: results[0].profile_picture });
        } else {
            res.status(404).json({ message: 'Profile picture not found' });
        }
    });
});




module.exports = router;