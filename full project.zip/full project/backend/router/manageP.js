const express = require('express');
const path = require('path');
const fs = require('fs'); 
const multer = require('multer'); 
const db = require('../db'); 
const router = express.Router();


const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, path.join(__dirname, '../../public/images'));
    },
    filename: function (req, file, cb) {
        
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });


router.get('/manage-profile', (req, res) => {
    if (req.session.userId) {
        
        res.sendFile(path.join(__dirname, '../../public', 'manage-profile.html'));
    } else {
        
        res.redirect('/login');
    }
});










// Route for retrieving the profile image based on the logged-in user
router.get('/get-profile-image', (req, res) => {
    if (req.session.userId) {
        const query = 'SELECT profile_picture FROM users WHERE id = ?';
        db.query(query, [req.session.userId], (err, result) => {
            if (err) {
                return res.status(500).json({ error: 'Database error' });
            }

            if (result.length > 0 && result[0].profile_picture) {
                res.json({ filePath: result[0].profile_picture });
            } else {
                res.json({ filePath: null });
            }
        });
    } else {
        res.status(401).json({ error: 'User not logged in' });
    }
});



// Assuming you have access to the 'db' object for database queries

router.post('/check-password', (req, res) => {
    const { currentPassword } = req.body; // Get the current password from the request body
    const userId = req.session.userId; // Assuming the user ID is stored in the session
    console.log("User ID from session:", userId);
    console.log("Received current password:", currentPassword); // Check if the password is coming through

    if (!userId) {
        return res.status(400).json({ isPasswordCorrect: false, message: 'User not logged in' });
    }

    // Get the user's current password from the database (this assumes plaintext passwords)
    db.query('SELECT password FROM users WHERE id = ?', [userId], (err, result) => {
        if (err) {
            console.error("Error fetching user password:", err);
            return res.status(500).json({ isPasswordCorrect: false, message: 'Error checking password.' });
        }

        if (result.length === 0) {
            return res.status(404).json({ isPasswordCorrect: false, message: 'User not found.' });
        }

        const storedPassword = result[0].password; // Assuming the password is stored in plaintext

        // Compare the stored password with the entered current password
        if (storedPassword === currentPassword) {
            return res.json({ isPasswordCorrect: true });
        } else {
            return res.status(400).json({ isPasswordCorrect: false, message: 'The old password is incorrect.' });
        }
    });
});



router.post('/update-profile', (req, res) => {
    const { name, email, password } = req.body;
    const userId = req.session.userId; // Assuming you're using session for user authentication

    if (!userId) { // Ensure the user is authenticated
        return res.status(400).json({ success: false, message: 'User not authenticated.' });
    }

    // If neither name, email, nor password is provided, return an error
    if (!name && !email && !password) {
        return res.status(400).json({ success: false, message: 'At least one field (name, email, password) must be provided.' });
    }

    // Start building the update query with optional parameters
    let query = 'UPDATE users SET';
    let queryParams = [];

    // Only update name if it's provided
    if (name) {
        query += ' name = ?';
        queryParams.push(name);
    }

    // Only update email if it's provided
    if (email) {
        if (queryParams.length > 0) query += ',';
        query += ' email = ?';
        queryParams.push(email);
    }

    // Only update password if it's provided
    if (password) {
        if (queryParams.length > 0) query += ',';
        query += ' password = ?';
        queryParams.push(password);  // No hashing, save the password as is
    }

    // Add the user ID to the query
    query += ' WHERE id = ?';
    queryParams.push(userId);

    // Execute the query
    db.query(query, queryParams, (err, result) => {
        if (err) {
            console.error('Error updating profile:', err);
            return res.status(500).json({ success: false, message: 'Error updating profile.' });
        }

        if (result.affectedRows > 0) {
            res.json({ success: true });
        } else {
            res.status(404).json({ success: false, message: 'User not found.' });
        }
    });
});















// Route to handle profile image upload and update the database
router.post('/upload-profile-image', upload.single('profileImage'), (req, res) => {
    if (req.session.userId) {
        // The uploaded file is available in req.file
        const filePath = '/images/' + req.file.filename; // Save the file path in the database

        const query = 'UPDATE users SET profile_picture = ? WHERE id = ?';
        db.query(query, [filePath, req.session.userId], (err, result) => {
            if (err) {
                return res.status(500).json({ error: 'Database error' });
            }

            // Respond with the file path after saving to the database
            res.json({ filePath: filePath });
        });
    } else {
        res.status(401).json({ error: 'User not logged in' });
    }
});

module.exports = router;
