const express = require('express');
const router = express.Router();
const mysql = require('mysql2');
const db = require("../db");
const path = require('path');


router.get('/view-products', (req, res) => {
    res.sendFile(path.join(__dirname, '../../public', 'home.html'));
});


router.get('/api/profile-picture', (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
        return res.status(401).json({ message: 'User not authenticated' });
    }

    const query = 'SELECT profile_picture FROM users WHERE id = ?';
    db.query(query, [userId], (error, results) => {
        if (error) {
            console.error('Error retrieving profile picture:', error);
            return res.status(500).json({ message: 'Error retrieving profile picture' });
        }

        if (results.length > 0) {
            res.json({ profilePicture: results[0].profile_picture });
        } else {
            res.status(404).json({ message: 'Profile picture not found' });
        }
    });
});



router.get('/api/products', (req, res) => {
    db.query(
        `SELECT p.id, p.name, p.image, p.price, p.category, p.status, u.name AS seller_name 
         FROM products p 
         JOIN users u ON p.seller_id = u.id 
         WHERE p.status = 'active'`,  
        (error, results) => {
            if (error) {
                console.error('Error retrieving products:', error);
                return res.status(500).json({ error: "Error retrieving products" });
            }
            res.json(results); 
        }
    );
});



module.exports = router;
