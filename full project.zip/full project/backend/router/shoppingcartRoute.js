
const express = require('express');
const router = express.Router();
const mysql = require('mysql2');
const db = require("../db");
const path = require('path');




router.get('/view-shopping-cart', (req, res) => {
    res.sendFile(path.join(__dirname, '../../public', 'shoppingcart.html'));
});




router.get('/api/getcartitems', (req, res) => {
    const userId = req.session.userId;
    if (!userId) {
        return res.status(401).json({ error: "User not logged in" });
    }

    const query = `
        SELECT 
            p.id AS product_id, 
            p.name AS product_name, 
            p.image AS product_image, 
            p.price AS product_price, 
            SUM(sc.quantity) AS quantity
        FROM shopping_cart sc
        JOIN products p ON sc.product_id = p.id
        WHERE sc.user_id = ?
        GROUP BY p.id, p.name, p.image, p.price
    `;

    db.query(query, [userId], (error, results) => {
        if (error) {
            console.error('Error retrieving cart data:', error);
            return res.status(500).json({ error: "Error retrieving cart data" });
        }

       
        results = results.map(item => ({
            ...item,
            quantity: Number(item.quantity)
        }));

        res.json(results);
    });
});


router.post('/addtocart/:id', (req, res) => {
    const { quantity, size, productId } = req.body; 
    const userId = req.session.userId; 

    console.log("The quantity is:", quantity, "The size is:", size, "The productId is:", productId);

    
    if (!userId) {
        return res.status(401).json({ message: 'User not authenticated' });
    }

    
    const productQuery = 'SELECT seller_id FROM products WHERE id = ?';

    db.query(productQuery, [productId], (error, results) => {
        if (error) {
            console.error('Error fetching product details:', error.message);
            return res.status(500).json({ message: 'Error fetching product details', error: error.message });
        }

        if (results.length === 0) {
            return res.status(404).json({ message: 'Product not found' });
        }

        const product = results[0];

        
        if (product.seller_id === userId) {
            return res.status(403).json({ message: 'You cannot add your own product to the cart' });
        }

        
        const addQuery = 'INSERT INTO shopping_cart (user_id, product_id, quantity, size) VALUES (?, ?, ?, ?)';
        
        db.query(addQuery, [userId, productId, quantity, size], (error, results) => {
            if (error) {
                console.error('Error adding item to cart:', error.message);
                return res.status(500).json({ message: 'Error adding item to cart', error: error.message });
            }

            
            res.status(201).json({ message: 'Item added to cart' });
            console.log("Item added to shopping_cart");
        });
    });
});









router.delete('/api/removefromcart/:productId', (req, res) => {
    const userId = req.session.userId;
    const productId = req.params.productId;

    const query = `DELETE FROM shopping_cart WHERE user_id = ? AND product_id = ?`;

    db.query(query, [userId, productId], (error) => {
        if (error) {
            console.error('Error removing item from cart:', error);
            return res.status(500).json({ error: "Error removing item from cart" });
        }
        res.sendStatus(200);
    });
});



router.delete('/api/clearfromcart', (req, res) => {
    const userId = req.session.userId;

    const query = `DELETE FROM shopping_cart WHERE user_id = ?`;

    db.query(query, [userId], (error) => {
        if (error) {
            console.error('Error clearing cart:', error);
            return res.status(500).json({ error: "Error clearing cart" });
        }
        res.sendStatus(200);
    });
});


router.put('/api/updatefromcart/:productId', (req, res) => {
    const userId = req.session.userId;
    const productId = req.params.productId;
    const action = req.body.action;

    const query = `SELECT quantity FROM shopping_cart WHERE user_id = ? AND product_id = ?`;

    db.query(query, [userId, productId], (error, results) => {
        if (error) {
            console.error('Error retrieving quantity:', error);
            return res.status(500).json({ error: "Error retrieving quantity" });
        }

        if (results.length > 0) {
            let newQuantity = results[0].quantity;

            if (action === 'increase') {
                newQuantity += 1;
            } else if (action === 'decrease' && newQuantity > 1) {
                newQuantity -= 1;
            }

            const updateQuery = `UPDATE shopping_cart SET quantity = ? WHERE user_id = ? AND product_id = ?`;
            db.query(updateQuery, [newQuantity, userId, productId], (error) => {
                if (error) {
                    console.error('Database update error:', error);
                    return res.status(500).json({ error: "Error updating cart quantity" });
                }

                const confirmQuery = `SELECT quantity FROM shopping_cart WHERE user_id = ? AND product_id = ?`;
                db.query(confirmQuery, [userId, productId], (error, confirmResults) => {
                    if (error) {
                        console.error('Error fetching updated quantity:', error);
                        return res.status(500).json({ error: "Error confirming updated quantity" });
                    }

                    res.status(200).json({ newQuantity: confirmResults[0].quantity });
                });
            });
        } else {
            res.status(404).json({ error: "Item not found in cart" });
        }
    });
});

module.exports = router;