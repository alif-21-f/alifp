const express = require('express');
const router = express.Router();
const db = require("../db");
const path = require('path');


router.use(express.urlencoded({ extended: true }));


router.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../../public', 'login.html'));
});


router.post('/signup', (req, res) => {
    const { name, email, password, startSelling } = req.body;
    const isSeller = startSelling ? true : false; 

    const userType = isSeller ? "seller" : "customer"; 

    
    const checkUserSql = "SELECT * FROM users WHERE email = ?";
    db.query(checkUserSql, [email], (error, result) => {
        if (error) {
            console.error('Error checking user:', error);
            return res.status(500).send("An error occurred while checking user existence.");
        }

        if (result.length > 0) {
            // User already exists
            res.redirect('/user?userExists=true');
        } else {
           
            const insertSql = `
                INSERT INTO users(name, email, password, user_type, profile_picture)
                VALUES(?, ?, ?, ?, '/images/profile-pic.jpg')
            `;
            db.query(insertSql, [name, email, password, userType], (error) => {
                if (error) {
                    console.error('Error inserting data:', error);
                    return res.status(500).send("An error occurred while registering.");
                }
              
                res.redirect('/user');
            });
        }
    });
});




router.post('/login', (req, res) => {
    const { email, password } = req.body;

    const sql = "SELECT * FROM users WHERE email = ? AND password = ?";
    db.query(sql, [email, password], (error, result) => {
        if (error) {
            console.error('Error logging in:', error);
            return res.status(500).send("An error occurred while logging in.");
        }

        if (result.length > 0) {
            const user = result[0];

            
            req.session.userId = user.id;

            
            if (user.user_type === 'seller') {
                
                res.redirect("/seller/view-page");
            } else if (user.user_type === 'customer') {
                
                res.redirect("/shop/view-products");
            } else {
                
                res.status(400).send("Unknown user type.");
            }
        } else {
            
            res.redirect("/user?loginFailed=true");
        }
    });
});



process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

module.exports = router;
