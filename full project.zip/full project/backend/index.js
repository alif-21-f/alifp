
const express = require('express');
const path = require('path');
const session = require('express-session');

const userRoutes=require("./router/user");
const shopRoutes=require("./router/shop");
const purchaseRoutes = require('./router/historyP');
const profileRoutes = require('./router/manageP');
const shoppingRoute=require('./router/shoppingcartRoute');
const sellerRoutes=require('./router/sellerRoute');
const sellerHistoryRoutes=require('./router/orderHistory');


const app = express();
const PORT = 3000;

app.use(session({
    secret: 'your-secret-key', 
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } 
}));

app.use(express.json());


app.use(express.urlencoded({ extended: true }));



app.use(express.static(path.join(__dirname, '../public')));



app.use("/user",userRoutes);
app.use('/seller',sellerRoutes);
app.use("/shop",shopRoutes);
app.use('/shoppingcart',shoppingRoute);
app.use('/history',purchaseRoutes);
app.use('/sellerhistory',sellerHistoryRoutes);
app.use('/profile',profileRoutes);




app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
