document.addEventListener("DOMContentLoaded", () => {
    fetchCartData();
    document.getElementById("confirm-purchase").addEventListener("click", confirmPurchase);
});


async function fetchCartData() {
    try {
        const response = await fetch('/shoppingcart/api/getcartitems');
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const cartData = await response.json();
        displayProducts(cartData);
        updateCartCount(cartData);
        displayCartItems(cartData); 
    } catch (error) {
        console.error('Error fetching cart data:', error);
    }
}


function displayProducts(cartData) {
    const productContainer = document.getElementById('product-container');
    productContainer.innerHTML = '';

    cartData.forEach(item => {
        const productCard = `
            <div class="col-md-3 py-3 product-card">
                <div class="card">
                    <img src="${item.product_image}" alt="${item.product_name}" class="product-image">
                    <div class="card-body">
                        <h3>${item.product_name}</h3>
                        <p>$${parseFloat(item.product_price).toFixed(2)}</p>
                        <button onclick="removeFromCart(${item.product_id})" class="btn btn-danger mt-2">Remove</button>
                    </div>
                </div>
            </div>
        `;
        productContainer.innerHTML += productCard;
    });
}


function displayCartItems(cartData) {
    const cartItemsContainer = document.getElementById('cart-items');
    cartItemsContainer.innerHTML = '';

    cartData.forEach(item => {
        const cartItem = `
            <div class="cart-item d-flex align-items-center" id="cart-item-${item.product_id}">
                <img src="${item.product_image}" alt="${item.product_name}" class="cart-item-image">
                <div class="cart-item-details ms-3">
                    <h3>${item.product_name}</h3>
                    <p>$${parseFloat(item.product_price).toFixed(2)}</p>
                    <div class="quantity-controls">
                        
                       <button onclick="updateQuantity(${item.product_id}, 'decrease')" class="btn btn-secondary">-</button>
                        <span id="count">${item.quantity}</span>
                         <button onclick="updateQuantity(${item.product_id}, 'increase')" class="btn btn-secondary">+</button>

                        
                    </div>
                    <button onclick="removeFromCart(${item.product_id})" class="btn btn-danger mt-2">Remove</button>
                </div>
            </div>
        `;
        cartItemsContainer.innerHTML += cartItem;
    });
}




function toggleCart() {
    const cartElement = document.getElementById('cart');
    cartElement.classList.toggle('visible');
    fetchCartData(); 
}


function updateCartCount(cartData) {
    document.getElementById('cart-count').textContent = cartData.reduce((total, item) => total + item.quantity, 0);
}


async function removeFromCart(productId) {
    try {
        const response = await fetch(`/shoppingcart/api/removefromcart/${productId}`, {
            method: 'DELETE'
        });
        if (response.ok) {
            fetchCartData(); 
        }
    } catch (error) {
        console.error('Error removing item from cart:', error);
    }
}

async function updateQuantity(productId, action) {
    try {
        const response = await fetch(`/shoppingcart/api/updatefromcart/${productId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ action })
        });

        console.log('Updating quantity for product:', productId, 'Action:', action);
        
        
        if (response.ok) {
            console.log("Quantity updated successfully.");
            fetchCartData(); 
        } else {
            
            const errorData = await response.json();
            console.error('Error from server:', errorData);
        }
    } catch (error) {
        console.error('Error updating item quantity:', error);
    }
}








async function confirmPurchase() {
    try {
        const response = await fetch('/history/api/confirm-purchase', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include' 
        });

        const result = await response.json();
        
        if (response.ok) {
            alert(result.message || 'Purchase confirmed! Thank you for your order.');
            clearCart(); 
        } else {
            alert(result.message || 'Failed to confirm purchase. Please try again.');
        }
    } catch (error) {
        console.error('Error confirming purchase:', error);
        alert('An error occurred while confirming your purchase.');
    }
}


async function clearCart() {
    try {
        const response = await fetch(`/shoppingcart/api/clearfromcart`, {
            method: 'DELETE'
        });
        if (response.ok) {
            fetchCartData(); 
        }
    } catch (error) {
        console.error('Error clearing cart:', error);
    }
}

