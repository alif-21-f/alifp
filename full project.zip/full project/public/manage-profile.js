// Element Selectors
const uploadButton = document.getElementById('upload-image-button');
const uploadTab = document.getElementById('upload-tab');
const cancelUploadButton = document.getElementById('cancel-upload-button');
const saveUploadButton = document.getElementById('save-upload-button');
const fileInput = document.getElementById('file-input');
const profileImage = document.getElementById('profile-image');
const dropZone = document.getElementById('drop-zone');
const email = document.getElementById('email');
const nameInput = document.getElementById('name');
const currentPassword = document.getElementById('current-password');
const newPassword = document.getElementById('new-password');
const confirmPassword = document.getElementById('repeat-new-password');
const saveButton = document.getElementById('save-button');


let originalProfileImageUrl = '';


function handleFetchError(response) {
    if (!response.ok) {
        return response.json().then(errorData => {
            console.error('Error response:', errorData);
            throw new Error(errorData.message || 'Network response was not ok');
        });
    }
    return response.json();
}


function loadProfileImage() {
    fetch('/profile/get-profile-image')
        .then(handleFetchError)
        .then(data => {
            originalProfileImageUrl = data.filePath
                ? `${data.filePath}?t=${new Date().getTime()}` 
                : 'https://bootdey.com/img/Content/avatar/avatar1.png'; 
            profileImage.src = originalProfileImageUrl;
        })
        .catch(error => console.error('Error fetching profile image:', error));
}
window.addEventListener('load', loadProfileImage);


uploadButton.addEventListener('click', () => {
    uploadTab.classList.remove('d-none');
    uploadTab.style.display = 'flex';
});


cancelUploadButton.addEventListener('click', () => {
    uploadTab.classList.add('d-none');
    uploadTab.style.display = 'none';
    fileInput.value = ''; 
    profileImage.src = originalProfileImageUrl; 
});


dropZone.addEventListener('click', () => fileInput.click());


fileInput.addEventListener('change', (event) => {
    const file = event.target.files[0];
    if (file && file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => profileImage.src = e.target.result;
        reader.readAsDataURL(file);
    }
});


dropZone.addEventListener('dragover', (event) => {
    event.preventDefault();
    dropZone.classList.add('drag-over');
});
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
dropZone.addEventListener('drop', (event) => {
    event.preventDefault();
    const file = event.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => profileImage.src = e.target.result;
        reader.readAsDataURL(file);
    }
});


function validatePasswords(currentPwd, newPwd, confirmedPwd) {
    return new Promise((resolve, reject) => {
        if (currentPwd) {
            if (newPwd !== confirmedPwd) {
                reject("New password and confirm password do not match.");
                return;
            }
            fetch('/profile/check-password', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ currentPassword: currentPwd })
            })
                .then(handleFetchError)
                .then(data => {
                    if (!data.isPasswordCorrect) reject("The old password is incorrect.");
                    else resolve();
                })
                .catch(() => reject('Error checking old password.'));
        } else {
            resolve();
        }
    });
}


saveButton.addEventListener('click', () => {
    const requestData = {
        name: nameInput.value || undefined,
        email: email.value || undefined,
        password: newPassword.value || undefined
    };

    validatePasswords(currentPassword.value, newPassword.value, confirmPassword.value)
        .then(() => {
            console.log("Data being sent to update profile:", requestData);
            return fetch('/profile/update-profile', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(requestData)
            });
        })
        .then(handleFetchError)
        .then(data => {
            if (data.success) {
                alert('Profile updated successfully!');
            } else {
                alert('Error updating profile.');
            }
        })
        .catch(error => alert(error.message || 'An error occurred while updating the profile.'));
});


saveUploadButton.addEventListener('click', () => {
    const file = fileInput.files[0];
    if (!file) {
        alert("Please select an image to upload.");
        return;
    }
    const formData = new FormData();
    formData.append("profileImage", file);

    fetch('/profile/upload-profile-image', {
        method: 'POST',
        body: formData
    })
        .then(handleFetchError)
        .then(data => {
            if (data.filePath) {
                originalProfileImageUrl = `${data.filePath}?t=${new Date().getTime()}`;
                profileImage.src = originalProfileImageUrl;
                alert('Profile image saved!');
                uploadTab.classList.add('d-none');
                uploadTab.style.display = 'none';
            } else {
                alert('Error saving profile image.');
            }
        })
        .catch(error => alert('Error uploading image.'));
});



document.getElementById("getBack").addEventListener("click", function() {
    window.history.back();
});