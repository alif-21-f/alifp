let products = []; 


document.addEventListener("DOMContentLoaded", () => {
    fetchProducts(); 
});


async function fetchProducts() {
    try {
        const response = await fetch('/seller/api/products');
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const data = await response.json();
        console.log('Fetched products:', data); 

        if (Array.isArray(data)) {
            products = data;
            renderProducts(products); 
        } else {
            throw new Error('Fetched products is not an array');
        }
    } catch (error) {
        console.error('Error fetching products:', error);
    }
}



function renderProducts(productsList) {
    console.log('Rendering products:', productsList); 
    
    const productContainer = document.getElementById('product-container');
    productContainer.innerHTML = '';  

    productsList.forEach(product => {
        console.log('Rendering product:', product); 

        const productCard = document.createElement('div');
        productCard.className = 'product-card';
        
        productCard.innerHTML = `
            <div class="product-image-container">
                <img src="${product.image}" alt="${product.name}">
            </div>
            <div class="product-info">
                <h3 class="product-name">${product.name}</h3>
                <p class="category"><strong>Category:</strong> ${product.category}</p>
                <div class="product-details">
                    <p class="price">$${product.price}</p>
                    <p class="quantity"><strong>Quantity:</strong> ${product.quantity}</p>
                </div>
            </div>
            <div class="product-actions">
                <i class="fas ${product.status === 'active' ? 'fa-play' : 'fa-pause'} pause" onclick="toggleStatus(${product.id})"></i>
                <i class="fas fa-edit" onclick="editProduct(${product.id})"></i>
                <i class="fas fa-trash delete" onclick="deleteProduct(${product.id})"></i>
            </div>
        `;
        productContainer.appendChild(productCard);
    });
}





function toggleStatus(id) {
    const product = products.find(p => p.id === id);

    
    if (!product) {
        console.error(`Product with id ${id} not found`);
        return;
    }

    
    console.log(`Before Update: ${product.status}`);

    
    const newStatus = product.status === 'active' ? 'paused' : 'active';
    product.status = newStatus;

    
    console.log(`After Update: ${product.status}`);

   
    fetch(`/seller/api/products-status/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            status: newStatus, 
        }),
    })
    .then(response => response.json())
    .then(data => {
        
        if (data.message === 'Product updated successfully') {
            console.log(`Product status updated to ${newStatus}`);
        } else {
            console.error('Error updating product status:', data);
        }

        
        renderProducts(products);
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error updating product status. Please try again.');
    });
}


async function deleteProduct(id) {
    try {
       
        const response = await fetch(`/seller/api/products/${id}`, {
            method: 'DELETE',
        });

        if (!response.ok) {
            throw new Error('Failed to delete product');
        }

        const data = await response.json();
        console.log(data.message); 

       
        await fetchProducts(); 

    } catch (error) {
        console.error('Error deleting product:', error);
        alert('Error deleting product. Please try again.');
    }
}




function filterProducts() {
    const searchTerm = document.getElementById('search').value.toLowerCase();
    const category = document.getElementById('category-select').value;
    const priceSort = document.getElementById('sort-price').value;

    
    let filteredProducts = products.filter(product => {
        return (
            (category === '' || product.category === category) &&
            (product.name.toLowerCase().includes(searchTerm)) 
        );
    });

    
    if (priceSort === 'low-to-high') {
        filteredProducts.sort((a, b) => a.price - b.price);
    } else if (priceSort === 'high-to-low') {
        filteredProducts.sort((a, b) => b.price - a.price);
    }

    
    renderProducts(filteredProducts);
}



document.addEventListener("DOMContentLoaded", function() {
    
    document.getElementById('sort-price').value = 'default';
    
    renderProducts(products);
});

const profilePic = document.getElementById('profileDropdown'); 
const dropdownMenu = document.querySelector('.dropdown-menu'); 

if (profilePic && dropdownMenu) {
    profilePic.addEventListener('click', () => {
        dropdownMenu.classList.toggle('active'); 
    });
} else {
    console.error('Profile picture or dropdown menu not found');
}



function showAddProductModal() {
    const modal = document.getElementById('add-product-modal');
    const productFields = document.getElementById('product-fields');
    const addProductBtn = document.getElementById('add-product-btn');
    
    
    console.log("Modal initial display: ", modal.style.display);  
    
    
    addProductBtn.style.display = 'block';   
    productFields.style.display = 'block';   
    
    modal.style.display = 'block'; 
    
    
    console.log("Modal display after change: ", modal.style.display);  
    console.log("Button visibility after change: ", addProductBtn.style.display);  
}

function closeAddProductModal() {
    const modal = document.getElementById('add-product-modal');
    modal.style.display = 'none';  
    const addProductBtn = document.getElementById('add-product-btn');
    addProductBtn.style.display = 'none'; 
}



async function addNewProduct() {
    const name = document.getElementById('product-name').value;
    const imageInput = document.getElementById('product-image-input');
    const price = document.getElementById('product-price').value;
    const quantity = document.getElementById('product-quantity').value;
    const category = document.getElementById('product-category').value; 

    
    if (name && imageInput.files.length > 0 && price && quantity && category) {
        const imageFile = imageInput.files[0]; 

        
        const formData = new FormData();
        formData.append('name', name);
        formData.append('category', category);
        formData.append('price', price);
        formData.append('quantity', quantity);
        formData.append('status', 'active');  
        formData.append('image', imageFile); 

        
        try {
            const response = await fetch('/seller/api/products', {
                method: 'POST',
                body: formData, 
            });

            if (response.ok) {
              
                fetchProducts();
                closeAddProductModal(); 
            } else {
                const errorData = await response.json();
                alert('Error adding product: ' + errorData.message);
            }
        } catch (error) {
            console.error('Error adding product:', error);
            alert('Error adding product to the server.');
        }
    } else {
        alert('Please fill out all fields and select a category!');
    }
}









document.addEventListener('DOMContentLoaded', function () {
    
    const imageContainer = document.getElementById('product-image-container');
    const imageInput = document.getElementById('product-image-input');
    const imagePreview = document.getElementById('product-image-preview');  

   
    imageContainer.addEventListener('click', function () {
        imageInput.click(); 
    });

    
    imageContainer.addEventListener('dragover', function (event) {
        event.preventDefault(); 
        imageContainer.classList.add('drag-over'); 
    });

    
    imageContainer.addEventListener('dragleave', function () {
        imageContainer.classList.remove('drag-over');
    });

    
    imageContainer.addEventListener('drop', function (event) {
        event.preventDefault();
        imageContainer.classList.remove('drag-over'); 

        const file = event.dataTransfer.files[0]; 

        if (file && file.type.startsWith('image/')) { 
            const reader = new FileReader();

            reader.onload = function (e) {
                
                imagePreview.src = e.target.result;
                imagePreview.style.display = 'block'; 
            };

            reader.readAsDataURL(file); 
        } else {
            alert('Please drop a valid image file.');
        }
    });

    
    imageInput.addEventListener('change', function (event) {
        const file = event.target.files[0]; 

        if (file && file.type.startsWith('image/')) { 
            const reader = new FileReader();

            reader.onload = function (e) {
               
                imagePreview.src = e.target.result;
                imagePreview.style.display = 'block'; 
            };

            reader.readAsDataURL(file); 
        } else {
            alert('Please select a valid image file.');
        }
    });
});


document.getElementById('edit-product-image-input').addEventListener('change', function (event) {
    const file = event.target.files[0]; 

    if (file && file.type.startsWith('image/')) { 
        const reader = new FileReader();

        reader.onload = function (e) {
            
            const imagePreview = document.getElementById('edit-product-image-preview');
            imagePreview.src = e.target.result;
            imagePreview.style.display = 'block'; 
        };

        reader.readAsDataURL(file); 
    } else {
        alert('Please select a valid image file.');
    }
});










let currentProductId = null; 

function editProduct(id) {
    console.log("editProduct triggered for id:", id);
    const product = products.find(p => p.id === id); 
    console.log("Found product:", product);
    
    if (product) {
        
        document.getElementById('edit-product-name').value = product.name;
        document.getElementById('edit-product-price').value = product.price;
        document.getElementById('edit-product-quantity').value = product.quantity;
        document.getElementById('edit-product-category').value = product.category;

        const imagePreview = document.getElementById('edit-product-image-preview');
        if (product.image) {
            imagePreview.src = product.image;
            imagePreview.style.display = 'block'; 
        } else {
            imagePreview.style.display = 'none'; 
        }

       
        const imageInput = document.getElementById('edit-product-image-input');
        imageInput.value = ''; 

       
        currentProductId = id;

        
        const modal = document.getElementById('edit-product-modal');
        modal.style.display = 'block';  

        
        const imageContainer = document.getElementById('edit-product-image-container');

       
        imageContainer.addEventListener('dragover', function (event) {
            event.preventDefault(); 
            imageContainer.classList.add('drag-over'); 
        });

        
        imageContainer.addEventListener('dragleave', function () {
            imageContainer.classList.remove('drag-over');
        });

        
        imageContainer.addEventListener('drop', function (event) {
            event.preventDefault();
            imageContainer.classList.remove('drag-over'); 

            const file = event.dataTransfer.files[0]; 

            if (file && file.type.startsWith('image/')) { 
                const reader = new FileReader();

                reader.onload = function (e) {
                    // Display the image preview
                    imagePreview.src = e.target.result;
                    imagePreview.style.display = 'block'; 

                    
                    const imageInput = document.getElementById('edit-product-image-input');
                    const dataTransfer = new DataTransfer(); 
                    const fileClone = new File([file], file.name, { type: file.type }); 
                    dataTransfer.items.add(fileClone); 
                    imageInput.files = dataTransfer.files; 
                };

                reader.readAsDataURL(file); 
            } else {
                alert('Please drop a valid image file.');
            }
        });

        
        imageInput.addEventListener('change', function (event) {
            const file = event.target.files[0];

            if (file && file.type.startsWith('image/')) { 
                const reader = new FileReader();

                reader.onload = function (e) {
                    // Display the image preview
                    imagePreview.src = e.target.result;
                    imagePreview.style.display = 'block'; 

                    
                };

                reader.readAsDataURL(file); 
            } else {
                alert('Please select a valid image file.');
            }
        });
    }
}


async function saveProductChanges() {
    const name = document.getElementById('edit-product-name').value;
    const price = document.getElementById('edit-product-price').value;
    const quantity = document.getElementById('edit-product-quantity').value;
    const category = document.getElementById('edit-product-category').value;
    const imageInput = document.getElementById('edit-product-image-input');
    const imageFile = imageInput.files[0]; 

    if (name && price && quantity && category) {
        const formData = new FormData();
        formData.append('name', name);
        formData.append('price', price);
        formData.append('quantity', quantity);
        formData.append('category', category);
        if (imageFile) {
            formData.append('image', imageFile); 
        }

        try {
            const response = await fetch(`/seller/api/products/${currentProductId}`, {
                method: 'PUT',
                body: formData,
            });

            if (response.ok) {
                
                fetchProducts(); 
                closeEditProductModal(); 
            } else {
                const errorData = await response.json();
                alert('Error updating product: ' + errorData.message);
            }
        } catch (error) {
            console.error('Error updating product:', error);
            alert('Error updating product to the server.');
        }
    } else {
        alert('Please fill in all required fields.');
    }
}

function closeEditProductModal() {
    const modal = document.getElementById('edit-product-modal');
    modal.style.display = 'none';  
}


// File input change event to handle manual image selection
document.getElementById('edit-product-image-input').addEventListener('change', function (event) {
    const file = event.target.files[0]; 

    if (file && file.type.startsWith('image/')) { 
        const reader = new FileReader();

        reader.onload = function (e) {
            
            const imagePreview = document.getElementById('edit-product-image-preview');
            imagePreview.src = e.target.result;
            imagePreview.style.display = 'block'; 
        };

        reader.readAsDataURL(file); 
    } else {
        alert('Please select a valid image file.');
    }
});




document.addEventListener('DOMContentLoaded', function() {
    const manage = document.getElementById('manage');

    if (manage) {
        manage.addEventListener('click', function() {
            console.log("Manage account clicked"); 
            window.location.href = '/profile/manage-profile'; 
        });
    } else {
        console.error("manage button element not found");
    }
});


document.addEventListener('DOMContentLoaded', function() {
    const homepage = document.getElementById('home');

    if (homepage) {
        homepage.addEventListener('click', function() {
            console.log("Manage account clicked"); 
            window.location.href = '/shop/view-products'; 
        });
    } else {
        console.error("manage button element not found");
    }
});


document.addEventListener('DOMContentLoaded', function() {
    const history = document.getElementById('history');

    if (history) {
        history.addEventListener('click', function() {
            console.log("Manage account clicked"); 
            window.location.href = '/sellerhistory/view-orders'; 
        });
    } else {
        console.error("manage button element not found");
    }
});
  






async function fetchProfilePicture() {
    try {
        const response = await fetch('/seller/api/profile-picture');
        
        if (!response.ok) {
            throw new Error('Failed to fetch profile picture');
        }
        
        const data = await response.json();
        
        
        const profileImageElement = document.getElementById('profileDropdown');
        
        if (data.profilePicture) {
            profileImageElement.src = data.profilePicture;  
        } else {
            console.log('Profile picture not found');
        }
    } catch (error) {
        console.error('Error fetching profile picture:', error);
    }
}


document.addEventListener('DOMContentLoaded', () => {
    fetchProfilePicture();
});
