
let products = [];


async function fetchProducts() {
    try {
        const response = await fetch('/shop/api/products');
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const data = await response.json();

       
        if (Array.isArray(data)) {
            products = data;
            console.log(products); 
            displayProducts('all'); 
        } else {
            throw new Error('Fetched products is not an array');
        }
    } catch (error) {
        console.error('Error fetching products:', error);
    }
}


function displayProducts(category) {
    const productContainer = document.getElementById('product-container');
    productContainer.innerHTML = ''; 

    
    const filteredProducts = category === 'all' 
        ? products 
        : products.filter(product => product.category.toLowerCase() === category.toLowerCase());

    
    if (filteredProducts.length === 0) {
        productContainer.innerHTML = '<p>No products found for this category.</p>';
        return;
    }

    
    filteredProducts.forEach(product => {
        const productCard = `
            <div class="col-md-3 py-3 py-md-0 product-card">
                <div class="card">
                    <img src="${product.image}" alt="${product.name}" class="product-image">
                    <div class="card-body">
                        <h3>${product.name}</h3>
                        <p>$${parseFloat(product.price).toFixed(2)} 
                           <a href="#" class="cart-icon" onclick="setProductDetails(${product.id}); return false;">
                               <i class="fa-solid fa-cart-shopping"></i>
                           </a>
                        </p>
                        <div class="seller-info">Seller: ${product.seller_name}</div> 
                    </div>
                </div>
            </div>
        `;
        productContainer.innerHTML += productCard; 
    });
}


function setProductDetails(productId) {
    const selectedProduct = products.find(product => product.id === productId);
    if (selectedProduct) {
        localStorage.setItem('selectedProduct', JSON.stringify(selectedProduct));
        customizeDrink(selectedProduct);
    }
}


document.querySelectorAll('.category-btn').forEach(button => {
    button.addEventListener('click', (event) => {
        const category = event.target.getAttribute('data-category');
        displayProducts(category); 
    });
});

function customizeDrink(product) {
    
    const modal = document.getElementById('customizeModal');  
    document.getElementById('modalProductImage').src = product.image;
    document.getElementById('modalProductName').innerText = product.name;
    document.getElementById('modalProductPrice').innerText = `$${parseFloat(product.price).toFixed(2)}`;
    document.getElementById('quantity').value = 1; 
    document.querySelectorAll('.size-option').forEach(btn => btn.classList.remove('selected'));

    
    const maxQuantity = product.maxQuantity || 10;  

    
    modal.style.display = 'flex';

    
    document.getElementById('closeModal').onclick = () => {
        modal.style.display = 'none';
    };

   
    document.querySelectorAll('.size-option').forEach(button => {
        button.addEventListener('click', () => {
            document.querySelectorAll('.size-option').forEach(btn => btn.classList.remove('selected'));
            button.classList.add('selected');
            product.size = button.dataset.size;
        });
    });

    
    document.getElementById('increaseQuantity').onclick = () => {
        let quantity = parseInt(document.getElementById('quantity').value, 10);
        if (quantity < maxQuantity) {
            document.getElementById('quantity').value = ++quantity;
        } else {
            alert(`Maximum quantity for this product is ${maxQuantity}`);
        }
    };

    document.getElementById('decreaseQuantity').onclick = () => {
        let quantity = parseInt(document.getElementById('quantity').value, 10);
        if (quantity > 1) {
            document.getElementById('quantity').value = --quantity;
        }
    };

    
    document.getElementById('addToCart').onclick = () => {
        const quantity = parseInt(document.getElementById('quantity').value, 10);
        const selectedSize = document.querySelector('.size-option.selected')?.dataset.size;

        if (selectedSize && quantity > 0) {
            product.size = selectedSize;
            product.quantity = quantity;
            addToCart(product, modal);  
            
            modal.style.display = 'none'; 
        } else {
            alert('Please select a size and quantity.');
        }
    };
}




const profilePic = document.getElementById('profileDropdown'); 
const dropdownMenu = document.querySelector('.dropdown-menu'); 

if (profilePic && dropdownMenu) {
    profilePic.addEventListener('click', () => {
        dropdownMenu.classList.toggle('active'); 
    });
} else {
    console.error('Profile picture or dropdown menu not found');
}






async function addToCart(product, modal) {
    try {
        const response = await fetch(`/shoppingcart/addtocart/${product.id}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                productId: product.id, 
                quantity: product.quantity, 
                size: product.size
            }),
        });

        const responseBody = await response.json();  

        if (!response.ok) {
            
            alert(responseBody.message || 'Failed to add item to cart');
            return;
        }

        
        alert(`Added ${product.quantity} ${product.size} ${product.name}(s) to cart.`);
        console.log('Response body:', responseBody);

        
        if (modal) {
            modal.style.display = 'none';  
        }
    } catch (error) {
        console.error('Error adding to cart:', error);
        alert('An error occurred while adding the product to the cart.');
    }
}




document.addEventListener('DOMContentLoaded', function() {
    const cartIcon = document.getElementById('cart-icon');

    if (cartIcon) {
        cartIcon.addEventListener('click', function() {
            console.log("Cart icon clicked"); 
            window.location.href = '/shoppingcart/view-shopping-cart'; 
        });
    } else {
        console.error("Cart icon element not found");
    }
});


document.addEventListener('DOMContentLoaded', function() {
    const history = document.getElementById('history');

    if (history) {
        history.addEventListener('click', function() {
            console.log("Manage account clicked"); 
            window.location.href = '/history/purchases'; 
        });
    } else {
        console.error("manage button element not found");
    }
});

document.addEventListener('DOMContentLoaded', function() {
    const manage = document.getElementById('manage');

    if (manage) {
        manage.addEventListener('click', function() {
            console.log("Manage account clicked"); 
            window.location.href = '/profile/manage-profile'; 
        });
    } else {
        console.error("manage button element not found");
    }
});


document.addEventListener('DOMContentLoaded', function() {
    const sellerpage = document.getElementById('sellerpage');

    if (sellerpage) {
        sellerpage.addEventListener('click', function() {
            console.log("Manage account clicked"); 
            window.location.href = '/seller/view-page'; 
        });
    } else {
        console.error("manage button element not found");
    }
});
  

async function fetchProfilePicture() {
    try {
        const response = await fetch('/shop/api/profile-picture');
        
        if (!response.ok) {
            throw new Error('Failed to fetch profile picture');
        }
        
        const data = await response.json();
        
        
        const profileImageElement = document.getElementById('profileDropdown');
        
        if (data.profilePicture) {
            profileImageElement.src = data.profilePicture;  
        } else {
            console.log('Profile picture not found');
        }
    } catch (error) {
        console.error('Error fetching profile picture:', error);
    }
}


document.addEventListener('DOMContentLoaded', () => {
    fetchProfilePicture();
});



document.addEventListener("DOMContentLoaded", () => {
    fetchProducts();
});



window.addEventListener("pageshow", (event) => {
    if (event.persisted) {
        window.location.reload(); 
    }
});

