let products = []; 


document.addEventListener("DOMContentLoaded", () => {
    fetchProducts();  
});


async function fetchProducts() {
    try {
        const response = await fetch('/sellerhistory/api/orders');  
        if (!response.ok) {
            throw new Error(`Network response was not ok: ${response.statusText}`);
        }
        const data = await response.json();
        console.log('Fetched products:', data);  

        if (Array.isArray(data)) {
            products = data;
            renderProducts(products); 
        } else {
            throw new Error('Fetched products is not an array');
        }
    } catch (error) {
        console.error('Error fetching products:', error);
    }
}

function renderProducts(productsList) {
    console.log('Rendering products:', productsList);  

    const productContainer = document.getElementById('product-container');
    productContainer.innerHTML = '';  

    
    productsList.forEach(product => {
        console.log('Rendering product:', product);  

        
        const productCard = document.createElement('div');
        productCard.className = 'product-card';

        
        productCard.innerHTML = `
            <div class="product-image-container">
                <img src="${product.product_image}" alt="${product.product_name}">
            </div>
            <div class="product-info">
                <h3 class="product-name">${product.product_name}</h3> <!-- Display product name -->
                <p class="category"><strong>Category:</strong> ${product.product_category}</p>
                <p class="customer-name"><strong>Customer:</strong> ${product.customer_name}</p> <!-- Display customer name -->
                <div class="product-details">
                    <p class="price">$${product.purchase_price}</p>
                    <p class="quantity"><strong>Quantity:</strong> ${product.purchase_quantity}</p>
                </div>
            </div>
        `;

        
        productContainer.appendChild(productCard);
    });
}



const profilePic = document.getElementById('profileDropdown'); 
const dropdownMenu = document.querySelector('.dropdown-menu'); 

if (profilePic && dropdownMenu) {
    profilePic.addEventListener('click', () => {
        dropdownMenu.classList.toggle('active'); 
    });
} else {
    console.error('Profile picture or dropdown menu not found');
}



async function fetchProfilePicture() {
    try {
        const response = await fetch('/sellerhistory/api/profile-picture');
        
        if (!response.ok) {
            throw new Error('Failed to fetch profile picture');
        }
        
        const data = await response.json();
        
       
        const profileImageElement = document.getElementById('profileDropdown');
        
        if (data.profilePicture) {
            profileImageElement.src = data.profilePicture;  
        } else {
            console.log('Profile picture not found');
        }
    } catch (error) {
        console.error('Error fetching profile picture:', error);
    }
}


document.addEventListener('DOMContentLoaded', () => {
    fetchProfilePicture();
});




document.addEventListener('DOMContentLoaded', function() {
    const manage = document.getElementById('manage');

    if (manage) {
        manage.addEventListener('click', function() {
            console.log("Manage account clicked"); 
            window.location.href = '/profile/manage-profile'; 
        });
    } else {
        console.error("manage button element not found");
    }
});

document.getElementById("getBack").addEventListener("click", function() {
    window.history.back();
});

window.addEventListener("pageshow", (event) => {
    if (event.persisted) {
        window.location.reload(); 
    }
});


