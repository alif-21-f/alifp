let currentCardSet = 0; 
const cardsPerPage = 4; 
let purchases = []; 


async function fetchPurchases() {
    try {
        const response = await fetch('/history/purchase-history'); 
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        purchases = await response.json(); 
        displayCards(); 
    } catch (error) {
        console.error('Error fetching purchases:', error);
        
    }
}


function displayCards() {
    const purchasesContainer = document.getElementById('purchases');
    purchasesContainer.innerHTML = ''; 

    const start = currentCardSet * cardsPerPage;
    const end = start + cardsPerPage;
    const currentPurchases = purchases.slice(start, end); 

    currentPurchases.forEach(purchase => {
        const card = document.createElement('div');
        card.className = 'purchase-card';
        card.innerHTML = `
            <img src="${purchase.image}" alt="${purchase.name}">
            <h3>${purchase.name}</h3>
            <p class="size">Size: ${purchase.size}</p>
            <p>Quantity: ${purchase.quantity}</p>
            <div class="seller">${purchase.sellerName}</div>
            <div class="price">${purchase.price}</div>
        `;
        purchasesContainer.appendChild(card);
    });
}


function changeCards(direction) {
    const maxCardSet = Math.ceil(purchases.length / cardsPerPage) - 1;

    currentCardSet += direction;
    if (currentCardSet < 0) {
        currentCardSet = 0; 
    } else if (currentCardSet > maxCardSet) {
        currentCardSet = maxCardSet; 
    }

    displayCards(); 
}


document.addEventListener("DOMContentLoaded", function() {
    
    document.getElementById('prevBtn').addEventListener('click', () => changeCards(-1));
    document.getElementById('nextBtn').addEventListener('click', () => changeCards(1));

    
    fetchPurchases();
});




const profilePic = document.getElementById('profileDropdown'); 
const dropdownMenu = document.querySelector('.dropdown-menu'); 

if (profilePic && dropdownMenu) {
    profilePic.addEventListener('click', () => {
        dropdownMenu.classList.toggle('active'); 
    });
} else {
    console.error('Profile picture or dropdown menu not found');
}



async function fetchProfilePicture() {
    try {
        const response = await fetch('/sellerhistory/api/profile-picture');
        
        if (!response.ok) {
            throw new Error('Failed to fetch profile picture');
        }
        
        const data = await response.json();
        
       
        const profileImageElement = document.getElementById('profileDropdown');
        
        if (data.profilePicture) {
            profileImageElement.src = data.profilePicture;  
        } else {
            console.log('Profile picture not found');
        }
    } catch (error) {
        console.error('Error fetching profile picture:', error);
    }
}


document.addEventListener('DOMContentLoaded', () => {
    fetchProfilePicture();
});




document.addEventListener('DOMContentLoaded', function() {
    const manage = document.getElementById('manage');

    if (manage) {
        manage.addEventListener('click', function() {
            console.log("Manage account clicked"); 
            window.location.href = '/profile/manage-profile'; 
        });
    } else {
        console.error("manage button element not found");
    }
});




document.getElementById("getBack").addEventListener("click", function() {
    window.history.back();
});
